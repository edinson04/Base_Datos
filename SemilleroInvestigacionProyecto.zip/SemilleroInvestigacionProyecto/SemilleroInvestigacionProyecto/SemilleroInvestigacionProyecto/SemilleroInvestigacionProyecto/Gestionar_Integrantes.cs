﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemilleroInvestigacionProyecto
{
    public partial class Gestionar_Integrantes : Form
    {
        public Gestionar_Integrantes()
        {
            InitializeComponent();
        }
    }
}
