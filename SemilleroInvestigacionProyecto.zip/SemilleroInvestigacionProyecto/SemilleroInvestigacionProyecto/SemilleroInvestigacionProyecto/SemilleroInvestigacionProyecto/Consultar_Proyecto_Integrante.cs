﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemilleroInvestigacionProyecto
{
    public partial class Consultar_Proyecto_Integrante : Form
    {
        public Consultar_Proyecto_Integrante()
        {
            InitializeComponent();
        }
    }
}
